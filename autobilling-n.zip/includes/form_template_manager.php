<?php
class FormTemplateManager {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function getTemplateById($id) {
        $query = "SELECT * FROM form_templates WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }
    
    public function getTemplateByType($type) {
        $query = "SELECT * FROM form_templates WHERE form_type = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $type);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }
    
    public function saveSubmission($templateId, $patientData, $pdfPath = null, $faxStatus = null) {
        $patientDataJson = json_encode($patientData);
        $query = "INSERT INTO form_submissions (form_template_id, patient_data, pdf_path, fax_status) 
                 VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "isss", $templateId, $patientDataJson, $pdfPath, $faxStatus);
        return mysqli_stmt_execute($stmt);
    }
    
    public function getAllTemplates() {
        $query = "SELECT * FROM form_templates";
        $result = mysqli_query($this->conn, $query);
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    
    public function storeTemplate($name, $formType, $content) {
        // Check if template with this type already exists
        $existingTemplate = $this->getTemplateByType($formType);
        
        if ($existingTemplate) {
            // Update existing template
            $query = "UPDATE form_templates SET name = ?, content = ? WHERE form_type = ?";
            $stmt = mysqli_prepare($this->conn, $query);
            mysqli_stmt_bind_param($stmt, "sss", $name, $content, $formType);
            return mysqli_stmt_execute($stmt);
        } else {
            // Insert new template
            $query = "INSERT INTO form_templates (name, form_type, content) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($this->conn, $query);
            mysqli_stmt_bind_param($stmt, "sss", $name, $formType, $content);
            return mysqli_stmt_execute($stmt);
        }
    }
}