<?php
/**
 * RingCentral Fax Service with cURL - No SDK Dependencies
 */
class RingCentralFaxService
{
    private $server;
    private $clientId;
    private $clientSecret;
    private $jwt;
    private $accessToken;
    private $refreshToken;
    private $tokenExpiry;
    
    public function __construct(array $config)
    {
        $this->server = $config['server'];
        $this->clientId = $config['clientId'];
        $this->clientSecret = $config['clientSecret'];
        $this->jwt = $config['jwt'];
        
        // Authenticate immediately
        $this->authenticate();
    }
    
    private function authenticate() {
        try {
            // Set up the cURL request for authentication
            $ch = curl_init($this->server . '/restapi/oauth/token');
            
            // Set up the request data
            $requestData = [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $this->jwt
            ];
            
            // Set cURL options
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($requestData));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Basic ' . base64_encode($this->clientId . ':' . $this->clientSecret),
                'Content-Type: application/x-www-form-urlencoded'
            ]);
            
            // Execute the request
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            // Check for errors
            if (curl_errno($ch)) {
                throw new Exception('cURL error: ' . curl_error($ch));
            }
            
            // Close the connection
            curl_close($ch);
            
            // Process the response
            if ($httpCode == 200) {
                $tokenData = json_decode($response, true);
                $this->accessToken = $tokenData['access_token'];
                $this->refreshToken = $tokenData['refresh_token'];
                $this->tokenExpiry = time() + $tokenData['expires_in'];
                return true;
            } else {
                error_log("RingCentral authentication failed with status: $httpCode. Response: $response");
                throw new Exception("Authentication failed with status: $httpCode");
            }
        } catch (Exception $e) {
            error_log("RingCentral authentication failed: " . $e->getMessage());
            return false;
        }
    }
    
    public function sendFaxFromBase64($base64Data, $filename, $faxNumber, $recipientName = '')
    {
        try {
            // Validate parameters
            if (empty($base64Data)) {
                throw new Exception("Base64 data is empty");
            }
            
            // Format fax number - ensure it includes country code (1 for US)
            $faxNumber = preg_replace('/[^0-9]/', '', $faxNumber);
            if (strlen($faxNumber) == 10) {
                $faxNumber = '1' . $faxNumber; // Add US country code if 10 digits
            }
            
            // Decode base64 to binary
            $pdfContent = base64_decode($base64Data);
            
            if ($pdfContent === false) {
                throw new Exception("Invalid base64 data provided");
            }
            
            // Create temporary file
            $tempFile = tempnam(sys_get_temp_dir(), 'fax_') . '.pdf';
            file_put_contents($tempFile, $pdfContent);
            
            // Use the sendFax method with the temporary file
            try {
                $result = $this->sendFaxFile($tempFile, $faxNumber, $recipientName);
                return $result;
            } finally {
                // Clean up temp file
                if (file_exists($tempFile)) {
                    unlink($tempFile);
                }
            }
        } catch (Exception $e) {
            error_log("Exception in sendFaxFromBase64: " . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    public function sendFax($pdfPath, $faxNumber, $recipientName = '', $isBase64 = false)
    {
        // If the input is base64 encoded, use the appropriate method
        if ($isBase64) {
            return $this->sendFaxFromBase64($pdfPath, "document.pdf", $faxNumber, $recipientName);
        }
        
        try {
            // Format fax number - ensure it includes country code (1 for US)
            $faxNumber = preg_replace('/[^0-9]/', '', $faxNumber);
            if (strlen($faxNumber) == 10) {
                $faxNumber = '1' . $faxNumber; // Add US country code if 10 digits
            }
            
            // Check if file exists
            if (!file_exists($pdfPath)) {
                error_log("File not found: $pdfPath");
                throw new Exception("PDF file not found: $pdfPath");
            }
            
            // Ensure file is readable
            if (!is_readable($pdfPath)) {
                error_log("File not readable: $pdfPath");
                throw new Exception("PDF file not readable: $pdfPath");
            }
            
            // Check file size
            $fileSize = filesize($pdfPath);
            if ($fileSize === false || $fileSize == 0) {
                error_log("Invalid file size for: $pdfPath");
                throw new Exception("Invalid PDF file size: $pdfPath");
            }
            
            // Use the direct file path for sending
            return $this->sendFaxFile($pdfPath, $faxNumber, $recipientName);
            
        } catch (Exception $e) {
            error_log("Exception in sendFax: " . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    private function sendFaxFile($filePath, $faxNumber, $recipientName = '') 
    {
        // Ensure we have valid token
        if (empty($this->accessToken) || time() > $this->tokenExpiry - 60) {
            $this->authenticate();
        }
        
        if (empty($this->accessToken)) {
            throw new Exception("Failed to authenticate with RingCentral");
        }
        
        // Generate a boundary for the multipart form data
        $boundary = md5(time());
        
        // Create the JSON data for recipient and settings
        $jsonData = json_encode([
            'to' => [['phoneNumber' => $faxNumber]],
            'faxResolution' => 'High',
            'coverPageText' => !empty($recipientName) ? "Medical documents for " . $recipientName : ''
        ]);
        
        // Initialize the cURL request
        $ch = curl_init($this->server . '/restapi/v1.0/account/~/extension/~/fax');
        
        // Read file content directly - no need for multipart preparation
        $fileContent = file_get_contents($filePath);
        if ($fileContent === false) {
            throw new Exception("Failed to read PDF file: $filePath");
        }
        
        // Create the multipart form data
        $data = [];
        
        // Add the JSON part
        $data[] = [
            'name' => 'json',
            'headers' => ['Content-Type: application/json'],
            'content' => $jsonData
        ];
        
        // Add the file part
        $data[] = [
            'name' => 'attachment',
            'filename' => basename($filePath),
            'headers' => ['Content-Type: application/pdf'],
            'content' => $fileContent
        ];
        
        // Build multipart request body
        $body = '';
        foreach ($data as $part) {
            $body .= "--$boundary\r\n";
            $body .= "Content-Disposition: form-data; name=\"{$part['name']}\"";
            
            if (isset($part['filename'])) {
                $body .= "; filename=\"{$part['filename']}\"";
            }
            
            $body .= "\r\n";
            
            foreach ($part['headers'] as $header) {
                $body .= "$header\r\n";
            }
            
            $body .= "\r\n{$part['content']}\r\n";
        }
        
        $body .= "--$boundary--\r\n";
        
        // Set cURL options
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: multipart/form-data; boundary=' . $boundary,
            'Content-Length: ' . strlen($body),
            'Accept: application/json'
        ]);
        
        // Execute the request
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        // Check for cURL errors
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            error_log("cURL error when sending fax: $error");
            throw new Exception("cURL error: $error");
        }
        
        // Close the connection
        curl_close($ch);
        
        // Log the response for debugging
        error_log("RingCentral fax API response: $response");
        
        // Process the response
        $responseData = json_decode($response, true);
        
        // Check if successful
        if ($httpCode >= 200 && $httpCode < 300) {
            error_log("Fax sent successfully!");
            return [
                'success' => true,
                'messageId' => $responseData['id'] ?? null,
                'status' => $responseData['messageStatus'] ?? 'Pending'
            ];
        } else {
            error_log("Failed to send fax. Status code: $httpCode, Response: $response");
            return [
                'success' => false,
                'message' => 'Failed to send fax. Status code: ' . $httpCode,
                'response' => $responseData
            ];
        }
    }
    
    public function checkFaxStatus($messageId) 
    {
        try {
            // Ensure we have valid token
            if (empty($this->accessToken) || time() > $this->tokenExpiry - 60) {
                $this->authenticate();
            }
            
            if (empty($this->accessToken)) {
                throw new Exception("Failed to authenticate with RingCentral");
            }
            
            // Initialize the cURL request
            $ch = curl_init($this->server . '/restapi/v1.0/account/~/extension/~/message-store/' . $messageId);
            
            // Set cURL options
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $this->accessToken,
                'Accept: application/json'
            ]);
            
            // Execute the request
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            // Check for cURL errors
            if (curl_errno($ch)) {
                $error = curl_error($ch);
                curl_close($ch);
                throw new Exception("cURL error: $error");
            }
            
            // Close the connection
            curl_close($ch);
            
            // Process the response
            $responseData = json_decode($response, true);
          
            // Check if successful
            if ($httpCode == 200) {
                return [
                    'success' => true,
                    'messageId' => $responseData['id'],
                    'status' => $responseData['messageStatus'],
                    'details' => $responseData
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to check fax status'
                ];
            }
        } catch (Exception $e) {
            error_log("Exception in checkFaxStatus: " . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}