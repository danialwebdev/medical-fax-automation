<?php
function isLoggedIn() {
    if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
        return true;
    }
    return false;
}

function redirectToLogin() {
    header("location: login.php");
    exit;
}

function redirectToDashboard() {
    header("location: dashboard.php");
    exit;
}

function logout() {
    $_SESSION = array();
    session_destroy();
    redirectToLogin();
}