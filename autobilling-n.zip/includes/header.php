<?php
require_once "includes/functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Billing System</title>
    
    <!-- Professional Medical Favicon -->
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect x='45' y='20' width='10' height='60' fill='%2300d8ff'/><rect x='20' y='45' width='60' height='10' fill='%2300d8ff'/><circle cx='50' cy='50' r='48' stroke='%2300d8ff' stroke-width='2' fill='none'/></svg>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">
    
    <!-- Mobile-specific meta tags -->
    <meta name="theme-color" content="#121212">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    
    <style>
        :root {
            --header-height: 60px;
            --sidebar-width: 250px;
            --primary-color: #00d8ff;  /* Medical teal/cyan */
            --secondary-color: #6c757d;
            --dark-color: #121212;
            --darker-color: #0a0a0a;
            --light-color: #f8f9fa;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            padding-top: var(--header-height);
            
        }
        
        .main-header {
            height: var(--header-height);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
            background: var(--darker-color);
            transition: all var(--transition-speed) ease;
            border-bottom: 1px solid rgba(0, 216, 255, 0.1);
        }
        
        .navbar-brand {
            font-weight: 600;
            font-size: 1.25rem;
            display: flex;
            align-items: center;
            color: var(--primary-color);
        }
        
        .navbar-brand i {
            font-size: 1.5rem;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            padding: 0.5rem 1rem;
            color: var(--light-color);
            transition: all var(--transition-speed) ease;
        }
        
        .user-profile:hover {
            color: var(--primary-color);
        }
        
        .user-profile img {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            margin-right: 0.5rem;
            object-fit: cover;
            border: 2px solid rgba(0, 216, 255, 0.3);
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-radius: 0.5rem;
            padding: 0.5rem;
            margin-top: 0.5rem;
            background-color: #2d2d2d;
            border: 1px solid rgba(0, 216, 255, 0.1);
        }
        
        .dropdown-item {
            border-radius: 0.25rem;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: all var(--transition-speed) ease;
            color: #e0e0e0;
        }
        
        .dropdown-item:hover {
            background-color: rgba(0, 216, 255, 0.1);
            color: var(--primary-color);
        }
        
        .dropdown-item i {
            width: 20px;
            text-align: center;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        .dropdown-divider {
            margin: 0.5rem 0;
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .dropdown-header {
            color: var(--primary-color);
        }
        
        .navbar-toggler {
            border: none;
            padding: 0.5rem;
            font-size: 1.25rem;
            color: var(--primary-color);
        }
        
        .navbar-toggler:focus {
            box-shadow: 0 0 0 2px rgba(0, 216, 255, 0.25);
        }
        
        .nav-link {
            color: #b0b0b0;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
        }
        
        .badge.bg-danger {
            background-color: #ff4d4d !important;
        }
        
        /* Notification dropdown specific styles */
        .dropdown-notifications .dropdown-item {
            border-left: 3px solid transparent;
        }
        
        .dropdown-notifications .dropdown-item:hover {
            border-left: 3px solid var(--primary-color);
            background-color: rgba(0, 216, 255, 0.05);
        }
        
        .text-muted {
            color: #8a8a8a !important;
        }
        
        /* Mobile specific styles */
        @media (max-width: 991.98px) {
            .navbar-collapse {
                background: var(--darker-color);
                padding: 1rem;
                margin-top: 0.5rem;
                border-radius: 0.5rem;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                border: 1px solid rgba(0, 216, 255, 0.1);
            }
            
            .user-profile {
                padding: 0.5rem 0;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid px-3 px-lg-4">
                <a class="navbar-brand" href="dashboard.php">
                    <i class="fas fa-hospital me-2"></i>
                    <span class="d-none d-sm-inline">Medical Billing System</span>
                    <span class="d-inline d-sm-none">MBS</span>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="fas fa-bars"></i>
                    </span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <!-- Notification Bell -->
                        <li class="nav-item dropdown me-2">
                            <a class="nav-link position-relative" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-bell fa-lg"></i>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                    3
                                    <span class="visually-hidden">unread notifications</span>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-notifications">
                                <li class="dropdown-header">Notifications (3)</li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0 me-3">
                                                <i class="fas fa-file-import text-primary"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="small">New patient record added</div>
                                                <span class="text-muted">2 minutes ago</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0 me-3">
                                                <i class="fas fa-check-circle text-success"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="small">Fax successfully sent</div>
                                                <span class="text-muted">1 hour ago</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0 me-3">
                                                <i class="fas fa-exclamation-triangle text-warning"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="small">Fax failed to send</div>
                                                <span class="text-muted">3 hours ago</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-center" href="#">View all notifications</a></li>
                            </ul>
                        </li>
                        
                        <!-- User Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle user-profile" href="#" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="assets/images/avatar.png" alt="User Avatar" class="img-fluid">
                                <span class="d-none d-lg-inline"><?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <div class="dropdown-header px-3 py-2">
                                        <div class="fw-bold"><?php echo htmlspecialchars($_SESSION["username"]); ?></div>
                                        <div class="small text-muted"><?php echo htmlspecialchars($_SESSION["email"] ?? 'user@example.com'); ?></div>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                                <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                                <li><a class="dropdown-item" href="#"><i class="fas fa-question-circle me-2"></i>Help</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Add smooth transitions
        document.addEventListener('DOMContentLoaded', function() {
            // Add animation to dropdowns
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.addEventListener('show.bs.dropdown', function () {
                    this.classList.add('animate__animated', 'animate__fadeIn');
                });
            });
            
            // Make navbar slightly transparent when scrolled
            window.addEventListener('scroll', function() {
                const header = document.querySelector('.main-header');
                if (window.scrollY > 10) {
                    header.style.background = 'rgba(10, 10, 10, 0.95)';
                } else {
                    header.style.background = 'var(--darker-color)';
                }
            });
        });
    </script>