<?php
session_start();
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u531037110_autobilling');
define('DB_PASSWORD', 'Devlet@786');
define('DB_NAME', 'u531037110_autobilling');

// Attempt to connect to MySQL database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Create admin table if not exists
$sql = "CREATE TABLE IF NOT EXISTS admin (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    // Check if admin exists
    $check = "SELECT * FROM admin";
    $result = $conn->query($check);
    if ($result->num_rows == 0) {
        // Insert default admin (username: admin, password: admin123)
        $username = "admin";
        $password = password_hash("admin123", PASSWORD_DEFAULT);
        $insert = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";
        $conn->query($insert);
    }
}
$ringcentralConfig = [
    "clientId" => "4MynUMZ4L6RcTjeTlmyAOI",
    "clientSecret" => "XsPNRKa330zfh6TmtAkrs0ZL4F8dqeAyqcKAqFXJbzMj",
    "server" => "https://platform.ringcentral.com",
    "jwt" => "eyJraWQiOiI4NzYyZjU5OGQwNTk0NGRiODZiZjVjYTk3ODA0NzYwOCIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJhdWQiOiJodHRwczovL3BsYXRmb3JtLnJpbmdjZW50cmFsLmNvbS9yZXN0YXBpL29hdXRoL3Rva2VuIiwic3ViIjoiMzIxNTU4NTAxNSIsImlzcyI6Imh0dHBzOi8vcGxhdGZvcm0ucmluZ2NlbnRyYWwuY29tIiwiZXhwIjozODkzNzU3MTIyLCJpYXQiOjE3NDYyNzM0NzUsImp0aSI6ImMwTmIxNEVXU2FxOXMyMXlhYVZwM1EifQ.fpzylS6NHOEaefRO27x6e3y2_i_fD-cH2Fv7rQJKn-2W2mpPJaVtdsd0cBc-4FEtMX942tP86DuDu1goGKriY27-XmmzeX-kOewf0amPPo4r3f4VR2N7E5pJfHB6-eq9p8eIFGJElezCWow0hdfrnMzknl-pAhsTYf1Iqo0Ijq2L0pbf-pyT8giPuZnhOVJ3DjigeWEkeZ89VtbrvmWnJe5ZlyJiLgX_Bsj6px8PL1O8zzRsTgZrI9ECJSdHCDxH-MVXrOsX-VTKBsh6ke-CLaqHyq3uPblGt-65QwfTyDdQCfd0FNehJnYdP--L2CFOYd9BgymmLWugfolxv1BOCw"
];
?>



