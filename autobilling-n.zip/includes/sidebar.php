<div class="sidebar-wrapper">
    <div class="sidebar">

        <!-- Collapsible Sidebar Content -->
        <div class="sidebar-content">
            <!-- Main Navigation -->
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                        <div class="nav-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <span class="nav-text">Dashboard</span>
                        <?php if(basename($_SERVER['PHP_SELF']) == 'dashboard.php'): ?>
                            <span class="nav-arrow">
                                <i class="fas fa-chevron-right"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
                
                 <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'send_data.php' ? 'active' : ''; ?>" href="send_data.php">
                        <div class="nav-icon">
                            <i class="fas fa-upload"></i>
                        </div>
                        <span class="nav-text">Send Data</span>
                        <?php if(basename($_SERVER['PHP_SELF']) == 'send_data.php'): ?>
                            <span class="nav-arrow">
                                <i class="fas fa-chevron-right"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_patients.php' ? 'active' : ''; ?>" href="view_patients.php">
                        <div class="nav-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <span class="nav-text">All Patients</span>
                        <?php if(basename($_SERVER['PHP_SELF']) == 'view_patients.php'): ?>
                            <span class="nav-arrow">
                                <i class="fas fa-chevron-right"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
                
               

                <!-- Additional Menu Items -->
                <!--<li class="nav-item">-->
                <!--    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" href="reports.php">-->
                <!--        <div class="nav-icon">-->
                <!--            <i class="fas fa-chart-bar"></i>-->
                <!--        </div>-->
                <!--        <span class="nav-text">Reports</span>-->
                <!--        <?php if(basename($_SERVER['PHP_SELF']) == 'reports.php'): ?>-->
                <!--            <span class="nav-arrow">-->
                <!--                <i class="fas fa-chevron-right"></i>-->
                <!--            </span>-->
                <!--        <?php endif; ?>-->
                <!--    </a>-->
                <!--</li>-->

                <!--<li class="nav-item">-->
                <!--    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">-->
                <!--        <div class="nav-icon">-->
                <!--            <i class="fas fa-cog"></i>-->
                <!--        </div>-->
                <!--        <span class="nav-text">Settings</span>-->
                <!--        <?php if(basename($_SERVER['PHP_SELF']) == 'settings.php'): ?>-->
                <!--            <span class="nav-arrow">-->
                <!--                <i class="fas fa-chevron-right"></i>-->
                <!--            </span>-->
                <!--        <?php endif; ?>-->
                <!--    </a>-->
                <!--</li>-->
            </ul>

            <!-- Sidebar Footer (Visible only on desktop) -->
            <div class="sidebar-footer d-none d-md-block mt-auto">
                <div class="user-info">
                    <img src="assets/images/avatar.png" alt="User" class="user-avatar">
                    <div class="user-details">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
                        <span class="user-role">Administrator</span>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    /* Sidebar Styles */
    :root {
        --sidebar-width: 250px;
        --sidebar-collapsed-width: 80px;
        --sidebar-bg: #ffffff;
        --sidebar-color: #495057;
        --sidebar-active-bg: rgba(13, 110, 253, 0.1);
        --sidebar-active-color: #0d6efd;
        --sidebar-hover-bg: rgba(0, 0, 0, 0.05);
        --sidebar-transition: all 0.3s ease;
    }

    .sidebar-wrapper {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        z-index: 1000;
        width: var(--sidebar-width);
        transition: var(--sidebar-transition);
        background: var(--sidebar-bg);
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    }

    .sidebar {
        display: flex;
        flex-direction: column;
        height: 100vh;
        overflow-y: auto;
    }

    .sidebar-header {
        padding: 1rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        text-decoration: none;
        color: var(--sidebar-color);
        font-size: 1.25rem;
    }

    .sidebar-content {
        display: flex;
        flex-direction: column;
        flex: 1;
        padding: 1rem 0;
    }

    .nav {
        flex-direction: column;
        padding-left: 0;
        margin-bottom: 0;
    }

    .nav-item {
        position: relative;
        margin: 0.25rem 0.5rem;
    }

    .nav-link {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        color: var(--sidebar-color);
        text-decoration: none;
        border-radius: 0.375rem;
        transition: var(--sidebar-transition);
    }

    .nav-link:hover {
        background: var(--sidebar-hover-bg);
        color: var(--sidebar-color);
    }

    .nav-link.active {
        background: var(--sidebar-active-bg);
        color: var(--sidebar-active-color);
        font-weight: 500;
    }

    .nav-icon {
        width: 24px;
        text-align: center;
        margin-right: 1rem;
        font-size: 1.1rem;
    }

    .nav-text {
        flex: 1;
    }

    .nav-arrow {
        color: var(--sidebar-active-color);
    }

    /* Sidebar Footer */
    .sidebar-footer {
        margin-bottom: 2rem !important;
        padding: 1rem;
        border-top: 1px solid rgba(0, 0, 0, 0.05);
        display: flex !important;
        align-items: center;
        justify-content: space-between;
    }

    .user-info {
        display: flex;
        align-items: center;
    }

    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        margin-right: 0.75rem;
        object-fit: cover;
        border: 2px solid rgba(0, 0, 0, 0.1);
    }

    .user-details {
        display: flex;
        flex-direction: column;
    }

    .user-name {
        font-weight: 500;
        font-size: 0.875rem;
    }

    .user-role {
        font-size: 0.75rem;
        color: #6c757d;
    }

    .logout-btn {
        color: #6c757d;
        padding: 0.5rem;
        border-radius: 50%;
        transition: var(--sidebar-transition);
    }

    .logout-btn:hover {
        color: #dc3545;
        background: rgba(220, 53, 69, 0.1);
    }

    /* Collapsed Sidebar */
    .sidebar-collapsed .sidebar-wrapper {
        width: var(--sidebar-collapsed-width);
    }

    .sidebar-collapsed .nav-text,
    .sidebar-collapsed .sidebar-brand span,
    .sidebar-collapsed .user-details,
    .sidebar-collapsed .logout-btn span {
        display: none;
    }

    .sidebar-collapsed .sidebar-header {
        padding: 1rem 0.5rem;
    }

    .sidebar-collapsed .nav-link {
        justify-content: center;
        padding: 0.75rem 0.5rem;
    }

    .sidebar-collapsed .nav-icon {
        margin-right: 0;
    }

    /* Mobile Responsiveness */
    @media (max-width: 767.98px) {
        .sidebar-wrapper {
            transform: translateX(-100%);
            z-index: 1040;
        }

        .sidebar-mobile-show .sidebar-wrapper {
            transform: translateX(0);
        }

        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1039;
            display: none;
        }

        .sidebar-mobile-show .sidebar-overlay {
            display: block;
        }
    }

    /* Dark Mode Support */
    @media (prefers-color-scheme: dark) {
        :root {
            --sidebar-bg: #212529;
            --sidebar-color: #dee2e6;
            --sidebar-active-bg: rgba(13, 110, 253, 0.2);
            --sidebar-hover-bg: rgba(255, 255, 255, 0.05);
        }

        .sidebar-header, .sidebar-footer {
            border-color: rgba(255, 255, 255, 0.05);
        }

        .user-role {
            color: #adb5bd;
        }
    }
</style>

<script>
    // // Toggle sidebar collapse
    // document.addEventListener('DOMContentLoaded', function() {
    //     const sidebarToggle = document.createElement('button');
    //     sidebarToggle.className = 'btn btn-sm btn-outline-secondary sidebar-toggle d-none d-md-block';
    //     sidebarToggle.innerHTML = '<i class="fas fa-chevron-left"></i>';
    //     sidebarToggle.style.position = 'fixed';
    //     sidebarToggle.style.left = '235px';
    //     sidebarToggle.style.top = '20px';
    //     sidebarToggle.style.zIndex = '1100';
    //     sidebarToggle.style.transition = 'all 0.3s ease';
        
    //     document.body.appendChild(sidebarToggle);
        
    //     sidebarToggle.addEventListener('click', function() {
    //         document.body.classList.toggle('sidebar-collapsed');
            
    //         if (document.body.classList.contains('sidebar-collapsed')) {
    //             this.innerHTML = '<i class="fas fa-chevron-right"></i>';
    //             this.style.left = '65px';
    //         } else {
    //             this.innerHTML = '<i class="fas fa-chevron-left"></i>';
    //             this.style.left = '235px';
    //         }
    //     });
        
        // Mobile sidebar toggle
        const mobileSidebarToggle = document.createElement('button');
        mobileSidebarToggle.className = 'btn btn-primary sidebar-mobile-toggle d-md-none';
        mobileSidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        mobileSidebarToggle.style.position = 'fixed';
        mobileSidebarToggle.style.bottom = '20px';
        mobileSidebarToggle.style.right = '20px';
        mobileSidebarToggle.style.zIndex = '1050';
        mobileSidebarToggle.style.width = '50px';
        mobileSidebarToggle.style.height = '50px';
        mobileSidebarToggle.style.borderRadius = '50%';
        
        document.body.appendChild(mobileSidebarToggle);
        
        const sidebarOverlay = document.createElement('div');
        sidebarOverlay.className = 'sidebar-overlay';
        document.body.appendChild(sidebarOverlay);
        
        mobileSidebarToggle.addEventListener('click', function() {
            document.body.classList.add('sidebar-mobile-show');
        });
        
        sidebarOverlay.addEventListener('click', function() {
            document.body.classList.remove('sidebar-mobile-show');
        });
    });
</script>