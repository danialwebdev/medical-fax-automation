<?php
// require_once 'form_template_manager.php';
require_once 'templates/medical-form.php';
require_once 'templates/pv-form.php';

class FormFactory {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function createForm($patientData) {
        // Determine which form to use based on "Braces Requested" field
        $bracesRequested = isset($patientData['Braces Requested']) ? $patientData['Braces Requested'] : '';
        
        if (stripos($bracesRequested, 'pv') !== false) {
            // Use PV Form
            return new PVForm($patientData);
        } else {
            // Use Medical Form (default)
            return new MedicalForm($patientData);
        }
    }
}