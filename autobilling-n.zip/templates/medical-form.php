<?php

class MedicalForm {
    private $data;
    private $formType;
    
    public function __construct($data) {
        // Ensure $data is an array
        if (!is_array($data)) {
            $this->data = [];
        } else {
            $this->data = $data;
        }
        
        // Determine form type from "Braces Requested" field
        $bracesRequested = isset($this->data['Braces Requested']) ? $this->data['Braces Requested'] : '';
        
        // Check for multiple brace types (like "BACK+BOTH KNEES")
        if (strpos($bracesRequested, '+') !== false) {
            $braceTypes = explode('+', $bracesRequested);
            // Use the first type for the form
            $bracesRequested = trim($braceTypes[0]);
        }
        
        // Determine form type with more specific checks
        if (strpos(strtolower($bracesRequested), 'wrist') !== false) {
            $this->formType = 'WRIST';
        } elseif (strpos(strtolower($bracesRequested), 'knee') !== false) {
            $this->formType = 'KNEE';
        } elseif (strpos(strtolower($bracesRequested), 'back') !== false) {
            $this->formType = 'BACK';
        } else {
            $this->formType = 'WRIST'; // Default form type
        }
    }
    
    public function generateHTML() {
        // Format the date to today's date if not provided
        $today = date('m/d/Y');
        
        // Safely access array keys
        $bracesRequested = isset($this->data['Braces Requested']) ? $this->data['Braces Requested'] : '';
        
        // Generate form header based on form type
        $formHeader = "PRIOR AUTHORIZATION PRESCRIPTION REQUEST FORM FOR " . $this->formType . " ORTHOSIS";
        
        // Generate form-specific fields
        list($diagnosisHTML, $affectedAreaHTML, $dispenseHTML, $additionalFieldsHTML) = $this->getFormSpecificContent();
        
        // Process provider details
        list($providerName, $providerAddress, $providerCity, $providerState, $providerZip) = $this->processProviderDetails();
        
        // Default length of need (months) - typically set to 99 (lifetime)
        $lengthOfNeed = "99";

return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Condition Form - {$this->formType}</title>
    <style>
        @page {
            margin: 20px;
            size: letter;
        }
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            font-size: 12pt;
        }
        
        .header {
            text-align: center;
            font-weight: bold;
            font-size: 16pt;
            margin-bottom: 10px;
        }
        
        .subheader {
            text-align: center;
            font-style: italic;
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 12pt;
        }
        
        .table-container {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .table-row {
            width: 100%;
        }
        
        .table-cell {
            border: 1px solid #000;
            padding: 8px;
            vertical-align: top;
        }
        
        .text-left {
            margin: 15px 0;
            font-style: italic;
            font-size: 11pt;
        }
        
        .diagnosis-section {
            margin: 20px 0;
        }
        
        .diagnosis-option {
            margin: 8px 0;
        }
        
        .checkbox {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 1px solid #000;
            position: relative;
            margin-right: 8px;
            vertical-align: middle;
        }
        
        .checkbox.checked:after {
            content: "✓";
            position: absolute;
            top: -4px;
            left: 1px;
        }
        
        .label {
            font-weight: bold;
            margin-right: 5px;
        }
        
        .form-value {
            display: inline-block;
            padding: 2px 0;
            min-width: 50px;
            border-bottom: 1px solid #999;
            font-weight: normal;
        }
        
        .signature-section {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature-field {
            font-weight: bold;
            flex: 1;
        }
        
        .signature-line {
            display: inline-block;
            min-width: 200px;
            border-bottom: 1px solid #000;
            margin-left: 10px;
        }
        
        .bold-text {
            font-weight: bold;
        }
        
        .affected-area-section {
            margin: 15px 0;
        }
        
        .product-section {
            margin: 15px 0;
            font-style: italic;
            font-weight: bold;
        }
        
        .dispense-section {
            margin: 15px 0;
        }
        
        .other-code-line {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        
        .line {
            flex-grow: 1;
            border-bottom: 1px solid #000;
            margin: 0 5px;
            min-width: 200px;
        }
        
        .length-of-need {
            margin-top: 15px;
        }
        
        .length-of-need-input {
            display: inline-block;
            width: 50px;
            text-align: center;
            border-bottom: 1px solid #000;
            font-weight: bold;
        }
        
        .length-of-need-note {
            margin-left: 10px;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header">
        {$formHeader}
    </div>
    
    <div class="subheader">
        Please Send RX Form & Pertinent Chart Notes<br>
        Return fax: 786-885-9812
    </div>
    
    <table class="table-container">
        <tr class="table-row">
            <td class="table-cell" style="width: 50%;">
                <div><span class="label">First:</span> <span class="form-value">{$this->escape(isset($this->data['First Name']) ? $this->data['First Name'] : '')}</span> <span class="label">Last:</span> <span class="form-value">{$this->escape(isset($this->data['Last Name']) ? $this->data['Last Name'] : '')}</span></div>
                <div><span class="label">DOB:</span> <span class="form-value">{$this->escape(isset($this->data['Date of Birth']) ? $this->data['Date of Birth'] : '')}</span></div>
                <div><span class="label">Gender:</span> <span class="form-value">{$this->escape(isset($this->data['Gender']) ? $this->data['Gender'] : '')}</span></div>
                <div><span class="label">Address:</span> <span class="form-value">{$this->escape(isset($this->data['Shipping Address']) ? $this->data['Shipping Address'] : '')}</span></div>
                <div><span class="label">City:</span> <span class="form-value">{$this->escape(isset($this->data['City']) ? $this->data['City'] : '')}</span></div>
                <div><span class="label">State:</span> <span class="form-value">{$this->escape(isset($this->data['State']) ? $this->data['State'] : '')}</span></div>
                <div><span class="label">Postal Code:</span> <span class="form-value">{$this->escape(isset($this->data['Zip Code']) ? $this->data['Zip Code'] : '')}</span></div>
                <div><span class="label">Patient Phone Number:</span> <span class="form-value">{$this->escape(isset($this->data['Phone Number']) ? $this->data['Phone Number'] : '')}</span></div>
                <div><span class="label">Primary Ins:</span> <span class="form-value">MEDICARE</span> <span class="label">Policy #:</span> <span class="form-value">{$this->escape(isset($this->data['Medicare ID']) ? $this->data['Medicare ID'] : '')}</span></div>
                <div><span class="label">Height:</span> <span class="form-value">{$this->escape(isset($this->data['Height']) ? $this->data['Height'] : '')}</span> <span class="label">Weight:</span> <span class="form-value">{$this->escape(isset($this->data['Weight']) ? $this->data['Weight'] : '')}</span></div>
                {$additionalFieldsHTML}
            </td>
            
            <td class="table-cell" style="width: 50%;">
                <div><span class="label">Date:</span> <span class="form-value">{$today}</span></div>
                <div><span class="label">Physician Name:</span> <span class="form-value">{$this->escape($providerName)}</span></div>
                <div><span class="label">NPI:</span> <span class="form-value">{$this->escape(isset($this->data['Provider NPI']) ? $this->data['Provider NPI'] : '')}</span></div>
                <div><span class="label">Address:</span> <span class="form-value">{$this->escape($providerAddress)}</span></div>
                <div><span class="label">City:</span> <span class="form-value">{$this->escape($providerCity)}</span></div>
                <div><span class="label">State:</span> <span class="form-value">{$this->escape($providerState)}</span></div>
                <div><span class="label">Postal code:</span> <span class="form-value">{$this->escape($providerZip)}</span></div>
                <div><span class="label">Phone Number:</span> <span class="form-value">{$this->escape(isset($this->data['Provider Phone']) ? $this->data['Provider Phone'] : '')}</span></div>
                <div><span class="label">Fax Number:</span> <span class="form-value"></span></div>
            </td>
        </tr>
    </table>
    
    <div class="text-left">
        This patient is being treated under a comprehensive plan of care for {$this->getFormDescription()} pain.
        <br>
        I, the undersigned; certify that the prescribed orthosis is medically necessary for the patient's overall well-being. 
        This patient has suffered injury and/or undergone surgery. In my opinion, the following orthosis product is both 
        reasonable and necessary in reference to treatment of the patient's condition and/or rehabilitation. 
        My patient has been in my care regarding the diagnosis below. This is the treatment I see fit for this patient at this time. 
        I certify that this information is true correct.
    </div>
    
    {$diagnosisHTML}
    
    {$affectedAreaHTML}
    
    <div class="product-section">
        <em>Our evaluation of the above patient has determined that providing the following {$this->formType} Orthosis Product will benefit this patient:</em>
    </div>
    
    {$dispenseHTML}
    
    <div class="signature-section">
        <div class="signature-field">Physician Signature: <span class="signature-line"></span></div>
        <div class="signature-field">Date Signed: <span class="form-value">{$today}</span></div>
    </div>
</body>
</html>
HTML;
    }
    
    private function getFormSpecificContent() {
        $diagnosisHTML = '';
        $affectedAreaHTML = '';
        $dispenseHTML = '';
        $additionalFieldsHTML = '';
        
        // Safely access array keys
        $bracesRequested = isset($this->data['Braces Requested']) ? $this->data['Braces Requested'] : '';
        
        switch ($this->formType) {
            case 'WRIST':
                // Check for different variations of wrist brace requests
                $leftWristChecked = (
                    stripos($bracesRequested, 'Left Wrist') !== false || 
                    stripos($bracesRequested, 'Both Wrist') !== false || 
                    stripos($bracesRequested, 'Both Wrists') !== false
                ) ? 'checked' : '';
                
                $rightWristChecked = (
                    stripos($bracesRequested, 'Right Wrist') !== false || 
                    stripos($bracesRequested, 'Both Wrist') !== false || 
                    stripos($bracesRequested, 'Both Wrists') !== false
                ) ? 'checked' : '';
                
                // Map diagnosis checkboxes to match the affected area
                $leftWristPainChecked = $leftWristChecked;
                $rightWristPainChecked = $rightWristChecked;
                
                // Diagnosis section
                $diagnosisHTML = <<<HTML
                <div class="diagnosis-section">
                    <div class="bold-text">Select ICD-10 Diagnosis Code:</div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$leftWristPainChecked}"></span>
                        <label>M25.532 - Pain in left wrist</label>
                    </div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$rightWristPainChecked}"></span>
                        <label>M25.531 - Pain in right wrist</label>
                    </div>
                
                    <div class="other-code-line">
                        <label>Other ICD-10 code:</label>
                        <span class="line"></span>
                    </div>
                </div>
                HTML;
                
                // Affected area section
                $affectedAreaHTML = <<<HTML
                <div class="affected-area-section">
                    <div class="bold-text">AFFECTED AREA: WRIST:</div>
                    <div style="margin-left: 30px; display: inline-block;">
                        <span class="checkbox {$leftWristChecked}"></span>
                        <span>Left</span>
                        <span style="margin-left: 30px;" class="checkbox {$rightWristChecked}"></span>
                        <span>Right</span>
                    </div>
                </div>
                HTML;
                
                // Dispense section
                $dispenseHTML = <<<HTML
                <div class="dispense-section">
                    <div class="bold-text">DISPENSE:</div>
                    <div>
                        <span>L3916 wrist, hand orthosis, includes one or more non torsion joint(s), elastic bands, turnbuckles, may include soft interface, straps, prefabricated, off the shelf</span>
                    </div>
                    
                    <div class="length-of-need">
                        <span>Estimated length of need (# of months): </span>
                        <span class="length-of-need-input">99</span>
                        <span class="length-of-need-note">6 - 99 (99=LIFETIME)</span>
                    </div>
                </div>
                HTML;
                break;
                
            case 'KNEE':
                // Check for different variations of knee brace requests
                $leftKneeChecked = (
                    stripos($bracesRequested, 'Left Knee') !== false || 
                    stripos($bracesRequested, 'Both Knee') !== false || 
                    stripos($bracesRequested, 'Both Knees') !== false
                ) ? 'checked' : '';
                
                $rightKneeChecked = (
                    stripos($bracesRequested, 'Right Knee') !== false || 
                    stripos($bracesRequested, 'Both Knee') !== false || 
                    stripos($bracesRequested, 'Both Knees') !== false
                ) ? 'checked' : '';
                
                // Also check for combined forms like "BACK+BOTH KNEES"
                if (stripos($bracesRequested, '+') !== false && stripos($bracesRequested, 'knee') !== false) {
                    $leftKneeChecked = 'checked';
                    $rightKneeChecked = 'checked';
                }
                
                // Map diagnosis codes to match affected areas
                $leftKneePainChecked = $leftKneeChecked;
                $rightKneePainChecked = $rightKneeChecked;
                $leftKneeOAChecked = '';
                $rightKneeOAChecked = '';
                
                // Diagnosis codes for knee
                $diagnosisHTML = <<<HTML
                <div class="diagnosis-section">
                    <div class="bold-text">Select ICD-10 Diagnosis Code:</div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$leftKneePainChecked}"></span>
                        <label>M25.562 - Pain in left knee</label>
                    </div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$rightKneePainChecked}"></span>
                        <label>M25.561 - Pain in right knee</label>
                    </div>
                    
                    <div class="diagnosis-option">
                        <span class="checkbox {$leftKneeOAChecked}"></span>
                        <label>M17.12 - Unilateral primary osteoarthritis, left knee</label>
                    </div>
                    
                    <div class="diagnosis-option">
                        <span class="checkbox {$rightKneeOAChecked}"></span>
                        <label>M17.11 - Unilateral primary osteoarthritis, right knee</label>
                    </div>
                
                    <div class="other-code-line">
                        <label>Other ICD-10 code:</label>
                        <span class="line"></span>
                    </div>
                </div>
                HTML;
                
                // Affected area section for knee
                $affectedAreaHTML = <<<HTML
                <div class="affected-area-section">
                    <div class="bold-text">AFFECTED AREA: KNEE:</div>
                    <div style="margin-left: 30px; display: inline-block;">
                        <span class="checkbox {$leftKneeChecked}"></span>
                        <span>Left</span>
                        <span style="margin-left: 30px;" class="checkbox {$rightKneeChecked}"></span>
                        <span>Right</span>
                    </div>
                </div>
                HTML;
                
                // Add thigh size field - use proper column name "KNEE SIZE"
                $additionalFieldsHTML = <<<HTML
                <div><span class="label">Knee Size:</span> <span class="form-value">{$this->escape(isset($this->data['KNEE SIZE']) ? $this->data['KNEE SIZE'] : '')}</span></div>
                HTML;
                
                // Dispense section for knee
                $dispenseHTML = <<<HTML
                <div class="dispense-section">
                    <div class="bold-text">DISPENSE:</div>
                    <div>
                        <span>L1851 Knee orthosis (KO), single upright, thigh and calf, with adjustable flexion and extension joint, medial-lateral and rotation control, with or without varus/valgus adjustment, prefabricated, off-the-shelf</span>
                    </div>
                    
                    <div class="length-of-need">
                        <span>Estimated length of need (# of months): </span>
                        <span class="length-of-need-input">99</span>
                        <span class="length-of-need-note">6 - 99 (99=LIFETIME)</span>
                    </div>
                </div>
                HTML;
                break;
                
            case 'BACK':
                // Determine which back pain diagnosis is checked based on data
                $lowBackPainChecked = 'checked'; // Default to checked for back forms
                $dorsopathyChecked = '';
                $discDegenerationChecked = '';
                $spinalInstabilityChecked = '';
                
                // Diagnosis codes for back
                $diagnosisHTML = <<<HTML
                <div class="diagnosis-section">
                    <div class="bold-text">Select ICD-10 Diagnosis Code:</div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$lowBackPainChecked}"></span>
                        <label>M54.5 - Low back pain</label>
                    </div>
                
                    <div class="diagnosis-option">
                        <span class="checkbox {$dorsopathyChecked}"></span>
                        <label>M53.9 – Dorsopathy, unspecified</label>
                    </div>
                    
                    <div class="diagnosis-option">
                        <span class="checkbox {$discDegenerationChecked}"></span>
                        <label>M51.36-Lumbar/ Lumbo sacral Inter vertebral Disc Degeneration.</label>
                    </div>
                    
                    <div class="diagnosis-option">
                        <span class="checkbox {$spinalInstabilityChecked}"></span>
                        <label>M53.2X7 - Spinal instabilities, lumbosacral region</label>
                    </div>
                
                    <div class="other-code-line">
                        <label>Other ICD-10 code:</label>
                        <span class="line"></span>
                    </div>
                </div>
                HTML;
                
                // No affected area section for back
                $affectedAreaHTML = '';
                
                // Add waist size field
                $additionalFieldsHTML = <<<HTML
                <div><span class="label">Waist Size:</span> <span class="form-value">{$this->escape(isset($this->data['Waist size']) ? $this->data['Waist size'] : '')}</span></div>
                HTML;
                
                // Dispense section for back
                $dispenseHTML = <<<HTML
                <div class="dispense-section">
                    <div class="bold-text">DISPENSE:</div>
                    <div>
                        <span>L0627 Lumbar orthosis, sagittal control, with rigid anterior and posterior panels, posterior extends from L-1 to below L-5 vertebra, produces intracavitary pressure to reduce load on the intervertebral discs, includes straps, closures, may include padding, shoulder straps, pendulous abdomen design, prefabricated, off-the-shelf</span>
                    </div>
                    
                    <div class="length-of-need">
                        <span>Estimated length of need (# of months): </span>
                        <span class="length-of-need-input">99</span>
                        <span class="length-of-need-note">6 - 99 (99=LIFETIME)</span>
                    </div>
                </div>
                HTML;
                break;
        }
        
        return [$diagnosisHTML, $affectedAreaHTML, $dispenseHTML, $additionalFieldsHTML];
    }
    
    private function getFormDescription() {
        switch ($this->formType) {
            case 'WRIST':
                return 'wrist';
            case 'KNEE':
                return 'knee';
            case 'BACK':
                return 'back';
            default:
                return 'orthopedic';
        }
    }
    
    private function processProviderDetails() {
        // Extract provider details - safely access with isset
        $providerName = isset($this->data['Provider Name']) ? $this->data['Provider Name'] : '';
        $providerNameParts = explode(',', $providerName);
        $providerName = isset($providerNameParts[0]) ? trim($providerNameParts[0]) : $providerName;

       // Extract provider address parts - safely access with isset
       $providerAddress = isset($this->data['Provider Address']) ? $this->data['Provider Address'] : '';

       // Normalize the address by replacing multiple spaces with single space
       $providerAddress = preg_replace('/\s+/', ' ', trim($providerAddress));
       
       // Initialize variables
       $providerStreetAddress = '';
       $providerCity = '';
       $providerState = '';
       $providerZip = '';
       
       // Most US states have 2-character abbreviations
       $states = [
           'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
           'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
           'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
           'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
           'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY',
           'DC', 'AS', 'GU', 'MP', 'PR', 'VI'
       ];
       
       // Split the address into parts
       $parts = explode(' ', $providerAddress);
       $numParts = count($parts);
       
       // Identify ZIP code (usually the last part, typically 5 digits or 5+4 digits)
       if ($numParts > 0 && preg_match('/^\d{5}(-\d{4})?$/', $parts[$numParts - 1])) {
           $providerZip = $parts[$numParts - 1];
           array_pop($parts); // Remove ZIP from parts
       } 
       
       // Identify state (usually before ZIP code, 2 uppercase letters)
       if (count($parts) > 0) {
           $potentialState = strtoupper(end($parts));
           if (in_array($potentialState, $states)) {
               $providerState = $potentialState;
               array_pop($parts); 
           }
       }
       
       // Try to identify city and street address
       if (count($parts) > 1) {
           // Take the last word as the city (simplistic approach)
           $providerCity = array_pop($parts);
           // The rest is the street address
           $providerStreetAddress = implode(' ', $parts);
       } else if (count($parts) == 1) {
           $providerStreetAddress = $parts[0];
       }
       
       return [$providerName, $providerStreetAddress, $providerCity, $providerState, $providerZip];
   }

    
    private function escape($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}