<?php

class PVForm {
    private $data;
    
    public function __construct($data) {
        // Ensure $data is an array
        if (!is_array($data)) {
            // If not an array, initialize with an empty array
            $this->data = [];
        } else {
            $this->data = $data;
        }
    }
    
    public function generateHTML() {
        // Format the date to today's date
        $today = date('m/d/Y');
        
        // Safely access array keys
        $firstName = isset($this->data['First Name']) ? $this->data['First Name'] : '';
        $lastName = isset($this->data['Last Name']) ? $this->data['Last Name'] : '';
        $birthdate = isset($this->data['Date of Birth']) ? $this->data['Date of Birth'] : '';
        $address = isset($this->data['Shipping Address']) ? $this->data['Shipping Address'] : '';
        $city = isset($this->data['City']) ? $this->data['City'] : '';
        $state = isset($this->data['State']) ? $this->data['State'] : '';
        $zipCode = isset($this->data['Zip Code']) ? $this->data['Zip Code'] : '';
        $medicareId = isset($this->data['Medicare ID']) ? $this->data['Medicare ID'] : '';
        $providerName = isset($this->data['Provider Name']) ? $this->data['Provider Name'] : '';
        $providerNpi = isset($this->data['Provider NPI']) ? $this->data['Provider NPI'] : '';
        $phoneNumber = isset($this->data['Phone Number']) ? $this->data['Phone Number'] : '';

return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Verification Form - PV</title>
    <style>
        @page {
            margin: 20px;
            size: letter;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            font-size: 12pt;
        }
        .header {
            width: 100%;
            margin-bottom: 15px;
        }
        .header-content {
            width: 100%;
            border-collapse: collapse;
        }
        .logo-cell {
            width: 250px;
            padding-right: 30px;
        }
        .title-cell {
            vertical-align: top;
        }
        .title-cell h2 {
            margin: 0;
            font-size: 20pt;
            font-weight: 600;
        }
        .title-cell p {
            margin: 5px 0;
            font-size: 18pt;
            font-weight: 500;
        }
        .sub-header {
            width: 100%;
            margin-bottom: 15px;
        }
        .instruction {
            font-size: 10pt;
            text-align: right;
        }
        .address {
            font-size: 10pt;
            text-align: left;
        }
        .date-field {
            font-size: 14pt;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .form-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .form-table th, .form-table td {
            border: 1px solid black;
            padding: 8px;
            font-size: 11pt;
        }
        .form-table th {
            background-color: #e0e0e0;
            font-weight: bold;
            text-align: left;
        }
        .section-header {
            background-color: #e0e0e0;
            font-weight: bold;
            font-size: 12pt;
            padding: 5px;
            border: 1px solid black;
            margin-bottom: 0;
        }
        .required {
            color: red;
            font-weight: bold;
        }
        .form-input {
            padding: 2px;
            min-height: 18px;
            display: inline-block;
            min-width: 120px;
        }
        .provider-sign .form-input {
            border-bottom: 1px solid #ff1b1b;
            min-width: 200px;
        }
        .provider-date .form-input {
            border-bottom: 1px solid #ff1b1b;
            min-width: 120px;
        }
        .checkbox-container {
            padding: 5px 0;
        }
        .checkbox-label {
            margin-right: 15px;
        }
        .checkbox {
            border: 1px solid #000;
            width: 12px;
            height: 12px;
            display: inline-block;
            margin-right: 5px;
        }
        .note {
            font-size: 10pt;
            font-style: italic;
            margin-top: 20px;
        }
        .note ol {
            margin: 5px 0 5px 20px;
            padding: 0;
        }
        .footer {
            font-size: 9pt;
            margin-top: 30px;
            text-align: center;
            padding-top: 5px;
            border-top: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <div class="header">
        <table class="header-content">
            <tr>
                <td class="logo-cell">
                    <img src="assets/images/logo.png" alt="Advantage MD Logo" style="width:100%;">
                </td>
                <td class="title-cell">
                    <h2>Active Patient Confirmation Form</h2>
                    <p>(Advantage MD)</p>
                    <p style="font-size:12pt;">FOR PROVIDER USE ONLY</p>
                </td>
            </tr>
        </table>
    </div>
    
    <table class="sub-header">
        <tr>
            <td class="address" width="50%">
                7231 Parkway Dr Suite<br>
                100, Hanover, MD<br>
                21076
            </td>
            <td class="instruction" width="50%">
                Complete this form and fax to the Enrollment Department at 1-786-845-9812<br>
                *Required Information
            </td>
        </tr>
    </table>
    
    <div class="date-field">
        <span class="required">*</span>Date: <span class="form-input">{$today}</span>
    </div>
    
    <div class="section-header">Member Information</div>
    <table class="form-table">
        <tr>
            <td colspan="2"><span class="required">*</span> First Name: <span class="form-input">{$this->escape($firstName)}</span></td>
            <td colspan="2"><span class="required">*</span> Last Name: <span class="form-input">{$this->escape($lastName)}</span></td>
            <td colspan="2"><span class="required">*</span> Birthdate: <span class="form-input">{$this->escape($birthdate)}</span></td>
        </tr>
        <tr>
            <td colspan="2">Member Address: <span class="form-input">{$this->escape($address)}</span></td>
            <td>City: <span class="form-input">{$this->escape($city)}</span></td>
            <td>State: <span class="form-input">{$this->escape($state)}</span></td>
            <td>Zip: <span class="form-input">{$this->escape($zipCode)}</span></td>
        </tr>
        <tr>
            <td colspan="3"><span class="required">*</span> Member ID#: <span class="form-input">{$this->escape($medicareId)}</span></td>
            <td colspan="2">
                <div class="checkbox-container">
                    <label class="checkbox-label">
                        <span class="checkbox"></span> HMO
                    </label>
                    <label class="checkbox-label">
                        <span class="checkbox"></span> PPO
                    </label>
                </div>
            </td>
        </tr>
    </table>
    
    <div class="section-header">Provider Information:</div>
    <table class="form-table">
        <tr>
            <td><span class="required">*</span>Primary Care Provider/Site Name<br><span class="form-input">{$this->escape($providerName)}</span></td>
            <td>NPI #: <span class="form-input">{$this->escape($providerNpi)}</span></td>
        </tr>
        <tr>
            <td>Staff Member Phone#<br><span class="form-input">{$this->escape($phoneNumber)}</span></td>
            <td>Patient is being seen this month 
                <span class="checkbox"></span> Yes 
                <span class="checkbox"></span> No
            </td>
        </tr>
        <tr>
            <td>Provider Staff Member Name<br><span class="form-input">N/A</span></td>
            <td class="provider-sign"><span class="required">*</span>Provider's signature:<span class="form-input"></span></td>
        </tr>
        <tr>
            <td>Provider ID Number<br><span class="form-input">N/A</span></td>
            <td class="provider-date">Date:<span class="form-input"></span></td>
        </tr>
    </table>
    
    <div class="note">
        <ol>
            <li>Please confirm whether the patient refuses under the care at this facility.</li>
            <li>If the patient has changed or switched to another provider, please mention the previous name and NPI.</li>
        </ol>
    </div>
    
    <div style="margin-top: 30px;">
        <label class="checkbox-label">
            <span class="checkbox"></span>
            I certify that I am the physician identified on the above section and I certify that the medical necessity information contained in this document is true, accurate and complete, to the best of my knowledge.
        </label>
    </div>
    
    <div class="footer">
        <p>Enrollment 2/2025</p>
        7231 Parkway Drive, Suite 100 | Hanover, MD 21076 | Ph no: 409 797-6369 | Fax: 786-885-9812 | <i>SC7024</i> 02/24 |
    </div>
</body>
</html>
HTML;
    }
    
    private function escape($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}